package frameWork;

import java.util.*;

public class GlobalVariables {
	public static final Map<String, String> exeMap = new LinkedHashMap<String, String>();

}
