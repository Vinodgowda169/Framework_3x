package frameWork;

import java.io.File;
import java.time.Duration;

import org.ini4j.Wini;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.fasterxml.jackson.databind.ObjectMapper;

public class GenericSeleniumActions {
	WebDriver driver;
	public static OrangeHrm ohm;
	public static Driver div;
	public static String MaxTime="";
	public GenericSeleniumActions(WebDriver drivers){
		this.driver = drivers;
		
	}
	
 public boolean click(String locator, String value) {
	 boolean status=false;
	 
	 try {
		 waitTillElementPresent(locator,value);
		 driver.findElement(By.xpath(value)).click();
		 
		 
		 status=true;
	 }catch (Exception e) {
e.printStackTrace();	}
	return status;
	 
 }
 
 public boolean enterText(String locator, String value,String text) {
	 boolean status=false;
	 
	 try {
		 waitTillElementPresent(locator,value);
		 driver.findElement(By.xpath(value)).sendKeys(text);
		 
		 status=true;
	 }catch (Exception e) {
e.printStackTrace();
}
	return status;
	 
 }
 
 public boolean launchApplication(String url) {
	 boolean status=false;
	 
	 try {
//		  url="https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
		 driver.get(url);
		 
		 status=true;
	 }catch (Exception e) {
		// TODO: handle exception
	}
	return status;
	 
 }
 
 public boolean waitTillElementPresent(String locator, String value) {
	 boolean status=false;
	 try {
		 JSONObject PrefValues= div.readINIFile("Dev");
		  MaxTime=PrefValues.get("MaxTime").toString();
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.valueOf(MaxTime)));
		 
		 
		 if(locator.equalsIgnoreCase("xpath")) {
			 wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(value)));
			 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(value)));
			 int size = driver.findElements(By.xpath(value)).size();
			 if(size==1) {
				 status=true;	 
			 } 
			 
		 }
		 
		 if(locator.equalsIgnoreCase("name")) {
			 wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.name(value)));
			 wait.until(ExpectedConditions.visibilityOfElementLocated(By.name(value)));
			 int size = driver.findElements(By.xpath(value)).size();
			 if(size==1) {
				 status=true;	 
			 } 
			 
		 }
		 
		
		 
		 status=true;
	 }catch (Exception e) {
		// TODO: handle exception
	}
	return status;
	 
 }

}
