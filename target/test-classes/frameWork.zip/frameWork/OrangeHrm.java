package frameWork;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class OrangeHrm {
public static 	GenericSeleniumActions gsa;
	WebDriver driver = null;
	public OrangeHrm(WebDriver driver) {
		this.driver=driver;
		

		 
	}
	public boolean Login(String username , String password,String url) {
		boolean status=false;
		 
		 try {
			  gsa=new GenericSeleniumActions(driver);
			 gsa.launchApplication(url);
			 gsa.enterText("xpath","//input[@name='username']" ,username);
			 gsa.enterText("xpath","//input[@name='password']" ,password);
			 gsa.click("xpath", "//button[text()=' Login ']");
			 
			 
			 
			 status=true;
		 }catch (Exception e) {
			 e.printStackTrace();
		}
		return status;
	}
		 

}
