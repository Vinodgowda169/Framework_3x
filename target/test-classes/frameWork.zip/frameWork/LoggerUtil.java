package frameWork;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

public class LoggerUtil {

//Generic logger — every class can use this
	public static Logger getLogger(Class<?> clazz) {
		String logRepName = GlobalVariables.exeMap.get("logFile");
		MDC.put("jobId", logRepName);
		return LoggerFactory.getLogger(clazz);
	}

}
